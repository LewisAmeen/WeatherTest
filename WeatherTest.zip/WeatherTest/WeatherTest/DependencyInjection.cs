﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherTest
{
    public class DependencyInjection
    {
        private IWeather weather;
        public DependencyInjection(IWeather weather)
        {
            this.weather = weather;
        }

        public void GetWeatherData(string cityName)
        {
            weather.Run(cityName);
        }
    }
}
