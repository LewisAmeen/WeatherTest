﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherTest
{
    internal class Settings
    {
        internal string URL = "https://api.openweathermap.org/data/2.5/weather";

        internal string ApiKey = "9b9bea2d75a107e39817969422f605db";

    }
}
