﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace WeatherTest
{
    internal class RestHelper
    {
        Settings settings;
        private string urlParameters = "?q={0}&appid={1}";

        public RestHelper()
        {
            settings = new Settings();
        }
        public WeatherData GetRest(string cityName)
        {
            WeatherData root = new WeatherData();
            HttpClient client = new HttpClient();
            try
            {
                
                client.BaseAddress = new Uri(settings.URL);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                urlParameters = String.Format(urlParameters, cityName, settings.ApiKey);
                HttpResponseMessage responseMessage = client.GetAsync(urlParameters).Result;
                if (responseMessage.IsSuccessStatusCode)
                {
                    var dataObjects = responseMessage.Content.ReadAsAsync<WeatherData>().Result;
                    root = dataObjects;

                }
                else
                {
                    Console.WriteLine("{0} ({1})", (int)responseMessage.StatusCode, responseMessage.ReasonPhrase);

                }
            }
            catch(System.AggregateException ex)
            {
                Console.WriteLine("Error : {0}", ex.Message);
            }
            catch(System.Exception ex)
            {
                Console.WriteLine("Error : {0}", ex.Message);
            }
            finally
            {
                client.Dispose();
            }
            
            return root;
        } 
    }
}
