﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherTest
{
    public class OpenWeather : IWeather
    {
        private const double KelvinValue = 273.15;

        public void DisplayWeather(WeatherData weatherData)
        {
            if (weatherData != null)
            {
                if (weatherData.main != null)
                {
                    Console.WriteLine("City :" + weatherData.name);
                    Console.WriteLine("Temp :{0} Celsius", Math.Round(weatherData.tempCelsius, 2));
                    Console.WriteLine("Feels Like :{0} Celsius", Math.Round(weatherData.feels_likeCelsius));
                    Console.WriteLine("Pressure :{0} hPa", weatherData.main.pressure);
                    Console.WriteLine("Humidity :{0} %\n", weatherData.main.humidity);
                    
                }
            }

        }

        public WeatherData GetWeather(string cityName)
        {
            RestHelper restHelper = new RestHelper();
            WeatherData weatherData = restHelper.GetRest(cityName);
            return weatherData;
        }

        public void ConvertWeather(ref WeatherData weatherData)
        {
            if (weatherData != null)
            {
                if (weatherData.main != null)
                {
                    weatherData.tempCelsius = weatherData.main.temp - KelvinValue;
                    weatherData.feels_likeCelsius = weatherData.main.feels_like - KelvinValue;
                }
            }
        }

        public void Run(string cityName)
        {
            var weatherData = GetWeather(cityName);
            ConvertWeather(ref weatherData);
            DisplayWeather(weatherData);

        }

    }
}
