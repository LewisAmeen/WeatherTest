﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherTest
{
    public interface IWeather
    { 
        public void DisplayWeather(WeatherData weatherData);

        public WeatherData GetWeather(string cityName);
        public void ConvertWeather(ref WeatherData weatherData);

        public void Run(string cityName);

    }
}
