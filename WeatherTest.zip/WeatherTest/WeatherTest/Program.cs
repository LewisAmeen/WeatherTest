﻿using System;

namespace WeatherTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Open Weather Client");

            DependencyInjection dependency = new DependencyInjection(new OpenWeather());

            dependency.GetWeatherData("Montreal");

            dependency.GetWeatherData("Toronto");
            
        }
    }
}